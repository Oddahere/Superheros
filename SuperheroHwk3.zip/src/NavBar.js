import React from 'react';

function NavBar(props) {
  return (
    <div className="navbar">
        <span id="logo">Superheros</span>
    </div>
  );
}

export default NavBar;
