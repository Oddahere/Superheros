import React from 'react';

//Search Stats and Name of Heros
function SearchResultItem(props) {
    const {data} = props;

    console.log('data', data);
    return(
        <div className="search-result">
            <div className="left">
                <img src={data.image.url} alt="img"/>
            </div>
            <div className="right">
                <h1>{data.name}</h1>
                <span style={{color: 'red', marginBottom: 5}}>{data.biography['full-name']}</span>
                <div className="stats">
                    <div>combat: {data.powerstats.combat}</div>
                    <div>durability: {data.powerstats.durability}</div>
                    <div>intelligence: {data.powerstats.intelligence}</div>
                    <div>power: {data.powerstats.power}</div>
                    <div>speed: {data.powerstats.speed}</div>
                    <div>strength: {data.powerstats.strength}</div>
                    <br></br>
                </div>
            </div>
        </div>
    );
}

export default SearchResultItem;