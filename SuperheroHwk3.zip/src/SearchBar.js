import React, {useState} from 'react';

//Adding the Search Bar
function SearchBar(props) {
    const {handleChange, searchText} = props;
  return (
    <div>
        <input 
        id="search-bar" 
        type="search" 
        placeholder="Superhero search"
        onChange={handleChange}
        value={searchText}
        >
    </input>
    </div>
  );
}

export default SearchBar;
